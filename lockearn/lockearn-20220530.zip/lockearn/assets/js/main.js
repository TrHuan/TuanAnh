jQuery(document).ready(function($) {
    setTimeout(function(){
        var hb = $('.header-stick').outerHeight();
        $('header').outerHeight(hb);
    }, 2000);

    $(window).resize(function(){
        setTimeout(function() {
            var hb = $('.header-stick').outerHeight();
            $('header').outerHeight(hb);
        }, 1000);
    });

    // var hbadm = $('#wpadminbar').outerHeight();

    $(window).on("scroll",function() {
        var hb = $('header').outerHeight();
        // var hb2= hbadm + hb;
        if ($(this).scrollTop() > hb ) {
            $('.header-stick').addClass('active');
            // $('.header-stick').css({"top": hbadm+"px"});
        }

        if ($(this).scrollTop() <= 0 ) {
            $('.header-stick').removeClass('active');
            // $('.header-stick').css({"top": "0px"});
        }

        if ($(this).scrollTop() > 0 ) {
            $('.back-to-top').addClass('active');
        } else {
            $('.back-to-top').removeClass('active');
        }
    });

    $('.back-to-top').click(function(){
        $('html, body').animate({scrollTop:0}, 400);
    }); 
});

jQuery(document).ready(function($) {
    // var swiper = new Swiper('.swiper-container');
    var swiper = new Swiper( '.swiper-slider-3d', {
        // pagination: '.swiper-pagination',
        // paginationClickable: true,
        effect: 'coverflow',
        loop: true,
        centeredSlides: true,
        slidesPerView: 'auto',
        autoplay: {
           delay: 2000,
        },
        speed: 2000,
        coverflow: {
            rotate: 0,
            stretch: 80,
            depth: 200,
            modifier: 1,
            slideShadows : false,
        }
    } );

});

// js popups
jQuery(document).ready(function($) {
    // popups
    $('.btn-popup').click(function(e){
        e.preventDefault();

        var adat = $(this).attr('data_popup');

        var hg_pop = $('.' + adat + ' .content-box').outerHeight();
        var hg_win = $(window).height();
        if (hg_pop >= hg_win) {    
            $('.popups .popups-content').height(hg_win - 30);
            $('.popups .popups-content').css({'top': '15px'});
        } else {    
            $('.popups .popups-content').height('auto');
            $('.popups .popups-content').css({'top': 'auto'});
        } 
        
        $('.popups.' + adat).addClass('active');
    });
    ////////////////////
    setTimeout(function(){
        var hg_pop = $('.popups.active .content-box').outerHeight();
        var hg_win = $(window).height();
        if (hg_pop >= hg_win) {    
            $('.popups .popups-content').height(hg_win - 30);
            $('.popups .popups-content').css({'top': '15px'});
        } else {    
            $('.popups .popups-content').height('auto');
            $('.popups .popups-content').css({'top': 'auto'});
        } 

        // $('.popups').addClass('active');
    }, 2000);  
    ////////////////////
    $('.popups, .popups-box .btn-back').click(function(e){
        e.preventDefault();

        $('.popups').removeClass('active');
    });
    ////////////////////
    $('.popups .content-box').click(function(e){
        e.stopPropagation();
    });
    ////////////////////
    $(window).resize(function(){
        var hg_pop = $('.popups.active .content-box').outerHeight();
        var hg_win = $(window).height();
        if (hg_pop >= hg_win) {    
            $('.popups .popups-content').height(hg_win - 30);
            $('.popups .popups-content').css({'top': '15px'});
        } else {    
            $('.popups .popups-content').height('auto');
            $('.popups .popups-content').css({'top': 'auto'});
        } 
    });

    $('.popup-content form.wpcf7-form .form-group-button .form-button .wpcf7-submit').click(function(){
        setTimeout(function(){
            var hg_pop = $('.popups.active .content-box').outerHeight();
            var hg_win = $(window).height();
            if (hg_pop >= hg_win) {    
                $('.popups .popups-content').height(hg_win - 30);
                $('.popups .popups-content').css({'top': '15px'});
            } else {    
                $('.popups .popups-content').height('auto');
                $('.popups .popups-content').css({'top': 'auto'});
            } 
        }, 2000);        
    });
});
// end js popups

// js tab
// jQuery(document).ready(function($) {
//     $('.title-tab .title').click(function(e){
//         e.preventDefault();

//         var ac = $(this).hasClass('active');

//         if (!ac) {
//             var tp = $(this).attr('data_tab');
//             $('.title-tab .title').removeClass('active');
//             $(this).addClass('active');
//             $('.tab-panel').removeClass('active');
//             $('.tab-panel.'+tp).addClass('active');
//         }
//     });
// });
// end js tab

// menu mobile
jQuery(document).ready(function($) {
    $('.megamenu-mobile .menu-close').click(function(e){
        e.preventDefault();
        $('.megamenu-mobile .mobile-content').removeClass('active');
    });

    $(document).on('click', '.megamenu-mobile .menu-open', function (e) {
        e.preventDefault();
        var whg = $(window).height();
        
        $('.megamenu-mobile .mobile-content').height(whg).delay(300).queue(function(next){
            $(this).addClass('active');
            next();
        });
    });

    $(window).resize(function(){
        var whg = $(window).height();

        $('.megamenu-mobile .mobile-content').height(whg);
    });
});
// end menu mobile

jQuery(document).ready(function($) {
    $(document).on('click', '.banner-frequently .banner-content .label', function () {
        // $('.banner-frequently .banner-content .content').slideUp();
        // $(this).next().slideDown();

        var hsac = $(this).hasClass('active');
        if (!hsac) {
            $('.banner-frequently .banner-content .content').slideUp();
            $(this).next().slideDown();

            $('.banner-frequently .banner-content .label').removeClass('active');
            $(this).addClass('active');
        }
    });
});

jQuery(document).ready(function($) {
    wow = new WOW(
      {
        animateClass: 'animated',
        offset:       100,
        callback:     function(box) {
            console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
        }
      }
    );
    wow.init();
    // document.getElementById('moar').onclick = function() {
    //     var section = document.createElement('section');
    //     section.className = 'section--purple wow fadeInDown';
    //     this.parentNode.insertBefore(section, this);
    // };
});